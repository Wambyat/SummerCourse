const process = {
    env : {
        OPENAI_API_KEY : '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'
    }
}